enum BikeCategory {
    MOUNTAIN_BIKE,
    ROAD_BIKE,
    BMX_BIKE,
    CRUISER_BIKE,
    DEFAULT
}

